<?php $__env->startSection('content'); ?>
<form method="post" action="{{ route('posts.store') }
    <?php echo csrf_field(); ?>
    <input name="body" type="text" value="" />
    <button type="submit">投稿する</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/New-biz/miniblog3/resources/views/posts/create.blade.php ENDPATH**/ ?>