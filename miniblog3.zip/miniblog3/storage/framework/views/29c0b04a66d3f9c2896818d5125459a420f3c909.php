<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card">
        <div class="card-header"><?php echo e($post->user->name); ?></div>
        <div class="card-body">
          <p class="card-text"><?php echo e($post->body); ?></p>
          <p class="card-text"><a href="<?php echo e(route('posts.show', $post->id)); ?>">詳細を見る</a></p>
          <?php if(Auth::id() === $post->user_id): ?>
            <form method="POST" action="<?php echo e(route('posts.delete', $post->id)); ?>">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-danger">削除</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/New-biz/miniblog3/resources/views/index.blade.php ENDPATH**/ ?>