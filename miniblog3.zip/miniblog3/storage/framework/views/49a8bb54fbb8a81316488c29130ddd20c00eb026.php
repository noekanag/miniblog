<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card">
      <div class="card-header"><?php echo e($post->user->name); ?></div>
      <div class="card-body">
        <p class="card-title"><?php echo e($post->body); ?></p>
      </div>
    </div>
  </div>

  <div class="container mt-4">
    <?php $__currentLoopData = $post->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card">
        <div class="card-header"><?php echo e($reply->user->name); ?></div>
        <div class="card-body">
          <p class="card-title"><?php echo e($reply->body); ?></p>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(auth()->guard()->check()): ?>
      <div class="card">
        <div class="card-header"><?php echo e(Auth::user()->name); ?></div>
          <div class="card-body">
            <form method="POST" action="<?php echo e(route('posts.reply', $post->id)); ?>">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <textarea name="body" class="form-control" rows="3"></textarea>
              </div>
              <button type="submit" class="btn btn-primary">返信する</button>
            </form>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/New-biz/miniblog3/resources/views/posts/show.blade.php ENDPATH**/ ?>