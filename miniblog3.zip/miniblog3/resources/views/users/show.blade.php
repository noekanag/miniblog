@extends('layouts.app')

@section('content')
  {{ $user->name }}
@endsection